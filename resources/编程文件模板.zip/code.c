#include<stdio.h>

/*begin*/
int add(int a, int b) {

}
/*end*/