#include <stdio.h>      //这是一个头文件
#include "code.h"
int main(){     
	int a;
	int b;
	scanf("%d %d", &a, &b);   //这是一个主函数体 
	int answer = add(a,b);
	printf("%d", answer);
} 
