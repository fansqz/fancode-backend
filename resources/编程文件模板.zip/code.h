#include <stdio.h>      //这是一个头文件

// 函数原型声明
int add(int a, int b);